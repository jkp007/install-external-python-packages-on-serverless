"""
SAM CLI version
"""

__version__ = "1.135.0"
